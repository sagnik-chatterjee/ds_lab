tuple1={'abcd',786,2.23,'john',70.2}
list1= ['abcd',786,2.23,'john',70.2]

tuple1[2]=1000 ## illegal access --> cant access like this 
list1[2]=1000 ##legal access --> can access list elements like this 
