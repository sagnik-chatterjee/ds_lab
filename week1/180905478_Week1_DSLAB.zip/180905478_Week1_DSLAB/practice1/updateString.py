var1= "Hello World"
print("Updated String is : ",var1[1:4]+'Python')

