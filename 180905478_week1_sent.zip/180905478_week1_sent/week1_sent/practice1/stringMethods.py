str1 = "this is a string example .... wow!!!"
#capitalize the string 
print(str1.capitalize())

#count the number of times a speicifc substring occurs in the string 
print(str1.count('s'))

## find()-> will locate the posn of searching substring 
print(str1.find('example'))

## lower()-> returns a copy of the string in all lowercase format 
print(str1.lower())

## replace() -> this method retunrs a copy of the string wiht all occurences of substring old replaced by new 

print(str1.replace("is","was"))

## swapcase()-> this method returns a copy of the string in which all the case based chars have their case swapped

print(str1.swapcase())


##title() -> returns a copy of the string in which first characters of all the words are capitalized 

print(str1.title())




