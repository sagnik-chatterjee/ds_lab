## python allows us to assign a single value to several variables simultaneously 
a=b=c=1
print(str(a)+""+str(b)+" "+str(c))
a,b,c=1,2,"john"
print(a)
print(b)
print(c)

