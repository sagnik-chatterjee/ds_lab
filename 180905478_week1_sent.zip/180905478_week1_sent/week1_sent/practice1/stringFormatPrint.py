print("My name is %s and weight is %d kg!" %('Anitha',55))


