counter=100 ## an int type assignment 
miles=1000.0 
name='John'
print(counter)
print(miles)
print(name)

