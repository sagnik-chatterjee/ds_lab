str="Hello World"
#print the complete string 
print(str)
#print the first char of the string 
print(str[0])

## print the characters starting from 3rd to 5th 
print(str[2:5])

## print all the characters strating from the 3rd 
print(str[2:])

#print string 2 times 
print(str*2) 

#print concatenated string 
print(str+"TEST")



