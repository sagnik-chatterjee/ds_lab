a=5 #int asignment 
b=4.56 # flaot type assignment 
print(5*a)
print(b//2)
print(a+b)
print(a**3)


